<?php
/**
 * Компонент Footer
 */
?>
<footer class="admin-footer">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-6">
                <p class="mb-0 text-muted">
                    Дякуємо за довіру до web студії <a href="https://flowaxy.com" target="_blank">FLOWAXY</a>
                </p>
            </div>
            <div class="col-md-6 text-md-end">
                <p class="mb-0 text-muted">
                    Версія 1.0.0
                </p>
            </div>
        </div>
    </div>
</footer>
